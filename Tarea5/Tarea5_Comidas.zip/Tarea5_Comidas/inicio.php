<?php
echo "Hola mundo";
?>